Initialization:
1. pip install --no-cache-dir -r requirements.txt
2. sh setup.sh
3. sh run.sh
4. sh status.sh
5. sh cleanup.sh 
-----------------------

To run:
sh run.sh
to close:
sh cleanup.sh